def myAdd(a, b) :
    return a + b

def mySubtract(a, b) :
    return a - b

def myMultiply (a, b) :
    return a * b

def myDivide(a, b) :
    return a / b

print (myAdd (10, 20))
print (mySubtract (10, 20))
print (myMultiply (10, 20))
print (myDivide (10, 20))
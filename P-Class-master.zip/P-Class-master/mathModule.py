
def myAdd(a, b) :
    return a + b

def mySubtract(a, b) :
    return a - b

def myMultiply (a, b) :
    return a * b

def myDivide(a, b) :
=======
def myAdd(a, b) :
    return a + b

def mySubtract(a, b) :
    return a - b

def myMultiply (a, b) :
    return a * b

def myDivide(a, b) :

    return a / b

import mathModule
import bankModule

mathModule.myAdd(10, 20)
mathModule.myAdd(10, 20)
mathModule.myAdd(10, 20)

o1 = bankModule.myBank("101", "KK", 250000)
print (o1.getBalance())


=======
=======

import mathModule

mathModule.myAdd(10, 20)
mathModule.myAdd(10, 20)
mathModule.myAdd(10, 20)


=======


import bankModule
o1 = bankModule.myBank("101", "KK", 250000)
print (o1.getBalance())


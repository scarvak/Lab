s1 = "sdfkdflkasjdf dsfvglkdfsvgljkasdf"

print (s1[0])
print (s1[1])
print (s1[2])

print (len(s1))

print (s1[32])

i = 0
for x in s1 :

    print("Character number : ", i, " >>> : ", x)
    #i = i + 1 #
    i += 1
    # print (x)


for j in range(10) :
    print (j)
for j in range(5,10) :
    print (j)

while True :
    print ("keep doing while it is true")
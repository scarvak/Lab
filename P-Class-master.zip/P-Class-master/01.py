print ("Hi PSE")

print ("Welcome to the Oil Merchant.")


print ("Start the day.")

# Comment - Anything u write will get ignored. Awesome to leave notes for your self.

print ("My sales today are : ") # this is a comment after a small code
""""
klsjdflkjsdf
.sdfklj
sdlfkjslkdjf
lksjdfsdfsdf
lkjsdflkjsdf
"""

# print ("2000")








print ("End the day.")
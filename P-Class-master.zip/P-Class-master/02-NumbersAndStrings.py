print ("This is a test print of text .,... !@#!@#ASDSDGF#$%#%12342354234 ")

# Variables - Change its value ... name to calll that value
a = 10
my_var_a = 20

print (a)

print (my_var_a)

b = 10
c = 10.3455

b  = 10.4566

print (b)
print ("b")
# Function - a peice of reusable code
print("!"*40)
print("Honey")
print("!"*40)


print("!"*50)
print("Yoyo")
print("!"*50)


print("!"*50)
print("Yoyo")
print("!"*50)


print("!"*50)
print("Yoyo")
print("!"*50)

# Math operations

oil_Palm_Price = 95
oil_Olive_Price = 35
oil_Sun_Price = 45

oil_Palm_Price = oil_Palm_Price + 10
print (oil_Palm_Price)

x = 10
y = 20

z = x + y
z = x - y
z = x / y
z = x * y
print (z)


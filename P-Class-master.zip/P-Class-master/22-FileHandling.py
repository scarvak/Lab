myFile = open("C:\\Users\\jcady\\PycharmProjects\\Proj1\\jusText1.txt")

# print (myFile.read())
"""
print (myFile.read(10))
print (myFile.read(10))
print (myFile.read(10))


print(myFile.readline())
print(myFile.readline())
print(myFile.readline())


for myText in myFile :
    print (myText)

"""

print(myFile.readline())
print(myFile.readline())
print(myFile.readline())
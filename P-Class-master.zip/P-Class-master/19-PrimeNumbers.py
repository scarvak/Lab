
print (100 % 4)

n = 1000
2, 3, 4, 1000/2

x = int(input("Enter a number to see if it is Prime"))

flag = 1

for i in range(2, x//2) :
    if ((x % i) == 0) :
        print ("NOT PRIME")
        flag = 0
        break

if (flag == 1) :
    print ("Prime Number")


# print all prime numbers below a given number

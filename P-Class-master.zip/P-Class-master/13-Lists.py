# Python Collections (Array) - List
# Key Value pair

xUN = "x"
xPwd = 1234

x = ["x", 1234]
y = ["y", 1235]
z = ["z", 1236]
print (x[0])
print (x[1])
# print (x[2])

print (x)
print (y)
print (z)

a1 = [10, 20.12, "abc", " sdfsdf kgosdgfdsfg dfgdfg"]

for item in a1 :
    print (item)

len = len(a1)
print (len)
a1.insert(2, "new text")
a1[2] = "new text 2"
a1.remove(2)
for item in a1 :
    print (item)


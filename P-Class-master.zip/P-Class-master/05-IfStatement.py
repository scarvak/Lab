# Conditions

if 2 > 3 :
    print ("That is true")
else :
    print("That is False")

x = 10
y = 1
if (x != y) :
    print("~"*50)
    print("That is true")
    print("~" * 50)

    print ("Just nothing")
else :
    print("~" * 50)
    print("That is false")
    print("~" * 50)

    print ("Will this always print!!!! - only when FALSE")

print ("Will this always print???")

# Comparison
# < > == != <= >=
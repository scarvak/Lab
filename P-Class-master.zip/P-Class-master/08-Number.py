# numbers

print (1.234)

pi1 = 22/7
pi2 = 3.1428

print (type(pi1), pi1)
print (len(str(pi1)))

print (round(pi1, 5))

# 5 to power of 3
# 5 * 5 * 5
print (pow(5, 10))

print (pow(2, 10))

print (max(10,101, 2003, 1))
print (min(10,101, 2003, 1, 50, 666))
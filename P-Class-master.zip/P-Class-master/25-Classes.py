# Python Classes

class my1stClass :
    a = 10
    b = 20

o1 = my1stClass()
print (o1.a, o1.b)

o2 = my1stClass()

o2.a = 40
o2.b = 80
print (o2.a, o2.b)
print (o1.a, o1.b)
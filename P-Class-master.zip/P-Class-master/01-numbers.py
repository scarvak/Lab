print ("Hi PSE")

print ("Welcome to the Oil Merchant.")


print ("Start the day.")

# Comment - Anything u write will get ignored. Awesome to leave notes for your self.

print ("My sales today are : ") # this is a comment after a small code
""""
klsjdflkjsdf
.sdfklj
sdlfkjslkdjf
lksjdfsdfsdf
lkjsdflkjsdf
"""

# print ("2000")







print ("This is forked and updated by KK")
print ("this is 2nd line")


print ("this is 4th line ----- from PyCharm")
=======
print ("this is 3nd line")r
print ("End the day.")


# Math operations

oil_Palm_Price = "$95"
oil_Olive_Price = "$35"
oil_Sun_Price = "$145"

oil_Palm_Stock = "50%"
oil_Olive_Stock = "35%"
oil_Sun_Stock = "90%"

# print (type(oil_Palm_Price))

print ("Oil price for Palm " + oil_Palm_Price)
print ("Stock for Palm " + oil_Palm_Stock)

print (oil_Palm_Price[0])
print (oil_Palm_Price[1])
print (oil_Palm_Price[2])

jusNumber = oil_Palm_Price[1] + oil_Palm_Price[2]
print (jusNumber)

print (type(jusNumber))

